var darkBkgndOn=0;
$( document ).ready(function() {
    makeImagesDraggable();
    defaults();
    
    
    /*
    $('.heads img,.body img,.legs img').each(
    function()
    {
        var offSetInit;
        $(this).mousedown(function()
                         {
            offSetInit=$(this).offset();
            console.log(offSetInit.top+" "+offSetInit.left);
        });
        
        $(this).mouseup(function()
                         {
            var offSet=$(this).offset();
            console.log(offSet.top+" "+offSet.left);
            
            
            var canvasOffset=$(".canvas").offset();
            if((offSet.left<canvasOffset.left || offSet.top<canvasOffset.top)||((offSet.left+$(this).width())>(canvasOffset.left+$(".canvas").width())||(offSet.top+$(this).height)>(canvasOffset.top+$(".canvas").height())))
                {
                    $(this).offset({top:offSetInit.top,left:offSetInit.left});  
                }
        });
    });
    */
    
    
    
    
    
    
    
    
    
    
    $("#load").click(function()
                    {
        darkOverlayToggle();
        $(".load-dialog-box").fadeIn("fast");
        $.get( "/cgi-bin/loaddesigns.pl", function( data ) {
              $( "#dump-designs" ).html( data );
        $("#close-load-designs-dialog").click(function()
                                             {
            darkOverlayToggle();
            $(".load-dialog-box").fadeOut("slow");
            
            });
        });
    });
    $("#save").click(function()
                    {
        darkOverlayToggle();
        $(".save-dialog-box").fadeIn("fast");
        $("#name").focus();
        //getTheRequiredXML();
    });
    $("#cancel_save").click(function(e)
                           {
        cancelButtonClicked();
        
    });
    $("#save_design").click(function()
                           {
        saveDesignNow();  
    });
});

function saveDesignNow()
{
    //var data="name="++"&array="+;
    //console.log(data);
  
    $.post( "/cgi-bin/savedesigns.pl", {
        name:$("#name").val(),xml:getTheRequiredXML()
    },function(data) {
  console.log("Server data "+data);
});
    darkOverlayToggle();
     $(".save-dialog-box").fadeOut("slow");
}
function cancelButtonClicked()
{
        //alert($(".save-dialog-box").css("display"));
        darkOverlayToggle();
        $(".save-dialog-box").fadeOut("slow");
}
function getTheRequiredXML()
{
    var ar=[];
    var xml='<?xml version="1.0" encoding="UTF-8"?><root>';
    $('.heads img,.body img,.legs img').each(function()
                                            {
        
        var pos=$(this).offset();
        //ar.push([pos.top,pos.left]);
        var tmpstr='<node><top>'+pos.top+'</top><left>'+pos.left+'</left></node>';
        xml+=tmpstr;
        //console.log(pos.left+" "+pos.top);
    });
    //console.log(ar.toString());
    xml+="</root>"
    //return JSON.stringify(ar.toString());
    console.log(xml);
    return xml;
}
function defaults()
{
}
function  makeImagesDraggable()
{
    $('.heads img,.body img,.legs img').each(function()
                                            {
        $(this).draggable();
    });
}

function darkOverlayToggle()
{
    if(darkBkgndOn==1)
        {
            darkBkgndOn=0;
            $(".dark-overlay").css("display","none")
            
        }
    else
        {
            darkBkgndOn=1;
            $(".dark-overlay").css("display","block");
        }
    
}   