$( document ).ready(function() {
   //makeImagesDraggable();
    var url = document.location.href,
    params = url.split('?')[1].split('&'),
    data = {}, tmp;
    for (var i = 0, l = params.length; i < l; i++) {
         tmp = params[i].split('=');
         data[tmp[0]] = tmp[1];
    }
    //console.log( "http://localhost/cgi-bin/getdesignforid.pl?id="+data.xml);
    $.get( "/cgi-bin/getdesignforid.pl?id="+data.xml, function( xml ) {
       parser = new DOMParser();
        xmlDoc = parser.parseFromString(xml,"text/xml");
        var tops=[];
        var lefts=[];
        
        x = xmlDoc.getElementsByTagName("top");
        for (i = 0; i < x.length; i++) {
            tops.push(x[i].childNodes[0].nodeValue);
        }
        x = xmlDoc.getElementsByTagName("left");
        for (i = 0; i < x.length; i++) {
            lefts.push(x[i].childNodes[0].nodeValue);
        }
        changePosOfImages(tops,lefts);
});
});

function changePosOfImages(tops,lefts)
{
    var index=0;
    $('.heads img,.body img,.legs img').each(function()
                                            {
        console.log(tops[index]+"   "+lefts[index]);
        $(this).offset({top:tops[index],left:lefts[index]});   
        index++;
    });
}
function  makeImagesDraggable()
{
    $('.heads img,.body img,.legs img').each(function()
                                            {
        $(this).draggable();
    });
}