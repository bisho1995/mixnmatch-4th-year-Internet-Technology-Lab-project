#!C:\Perl64\bin\perl.exe
 use DBI;
 use CGI;	
 use CGI::Carp qw(fatalsToBrowser);
 
  my $cgi = new CGI;

# output the content-type so the web server knows

print $cgi->header;
 
$dbh = DBI->connect('dbi:mysql:mixnmatch','root','password')
     or die "Connection Error: $DBI::errstr\n";

 $sql = "select * from designs";
 $sth = $dbh->prepare($sql);
 $sth->execute;
 while (@row = $sth->fetchrow_array) {
     print "<a target='_blank' href='/mixnmatch/viewer.html?xml=$row[0]'>$row[1]</a><br>";
 } 
 
 
 
 