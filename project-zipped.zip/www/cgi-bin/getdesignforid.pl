#!C:\Perl64\bin\perl.exe
 use DBI;
 use CGI;	
 use CGI::Carp qw(fatalsToBrowser);
 
 my $cgi = new CGI;

# output the content-type so the web server knows

print $cgi->header;

if ($cgi->param()) {
	my $id=$cgi->param('id');
	$dbh = DBI->connect('dbi:mysql:mixnmatch','root','password')
     or die "Connection Error: $DBI::errstr\n";
	$sql = "select design from designs where id=$id";
	 $sth = $dbh->prepare($sql);
	 $sth->execute;
	 while (@row = $sth->fetchrow_array) {
		 print $row[0];
	 } 
}