#!C:\Perl64\bin\perl.exe
 use DBI;
 use CGI;	
 use CGI::Carp qw(fatalsToBrowser);
 
 my $cgi = new CGI;

# output the content-type so the web server knows

print $cgi->header;
print '<html><head><title>Basic CGI</title></head><body>';

if ($cgi->param()) {
    # Parameters are defined, therefore the form has been submitted
     my $name=$cgi->param('name');
     print $name;
     my $xml=$cgi->param('xml');
	 print $xml;
     $dbh = DBI->connect('dbi:mysql:mixnmatch','root','password')
     or die "Connection Error: $DBI::errstr\n";

$dbh->do("INSERT INTO designs(name,design) VALUES ( ?, ?)", undef, $name,$xml);

}



print "</body></html>\n";