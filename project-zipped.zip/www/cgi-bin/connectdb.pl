#!C:\Perl64\bin\perl.exe
 use DBI;
 use CGI;	
 
 my $cgi = new CGI;

# output the content-type so the web server knows

print $cgi->header;
print '<html><head><title>Basic CGI</title><head><body>';

 $dbh = DBI->connect('dbi:mysql:mixnmatch','root','password')
     or die "Connection Error: $DBI::errstr\n";

$dbh->do("INSERT INTO designs(name,design) VALUES ( ?, ?)", undef, "Jochen","garbage");



print "</body></html>\n";