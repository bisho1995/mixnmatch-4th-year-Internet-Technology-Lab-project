#!c:/strawberry/perl/bin/perl
use strict;
use CGI;
my $q = new CGI;

# print header and start the markup output
print $q-?header("text/html");
print $q-?start_html("Test Perl CGI");
print $q-?h2("Perl/CGI is running");
print $q-?h3("Congratulations...");
print $q-?end_html;